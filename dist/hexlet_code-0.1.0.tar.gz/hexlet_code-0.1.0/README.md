### Hexlet tests and linter status:
[![Actions Status](https://github.com/al-ov73/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/al-ov73/python-project-49/actions)

<a href="https://codeclimate.com/github/al-ov73/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/10c87f0215ca87a98a31/maintainability" /></a>

https://asciinema.org/a/605594
