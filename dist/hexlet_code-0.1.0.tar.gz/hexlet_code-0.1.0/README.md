### Hexlet tests and linter status:
[![Actions Status](https://github.com/al-ov73/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/al-ov73/python-project-49/actions)